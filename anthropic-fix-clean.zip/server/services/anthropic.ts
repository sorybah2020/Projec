import Anthropic from '@anthropic-ai/sdk';
import { Expense, expenseCategories } from '@shared/schema';

// Function to check if API key exists and is valid format
function validateApiKey(apiKey?: string): boolean {
  // Check if key exists
  if (!apiKey) {
    console.warn("Anthropic API key is missing");
    return false;
  }
  
  // Basic validation for Anthropic key format
  if (apiKey.length < 10) {
    console.warn("Anthropic API key appears to be malformed (too short)");
    return false;
  }
  
  return true;
}

// Updates the current Anthropic client with a new API key
export function updateAnthropicClient(newApiKey: string): void {
  // Update the environment variable
  process.env.ANTHROPIC_API_KEY = newApiKey;
  
  // Re-initialize the Anthropic client with the new key
  anthropic = getAnthropicClient();
  
  console.log("Anthropic client successfully updated with new API key");
}

export async function testApiKey(testApiKey: string): Promise<{ valid: boolean; message: string }> {
  try {
    // Basic format validation first
    if (!validateApiKey(testApiKey)) {
      return { 
        valid: false, 
        message: "API key is invalid (too short)" 
      };
    }
    
    // Create a temporary Anthropic client with the test key
    const testClient = new Anthropic({
      apiKey: testApiKey
    });
    
    // Make a minimal request to test the key
    // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
    await testClient.messages.create({
      model: "claude-3-7-sonnet-20250219",
      messages: [{ role: "user", content: "Hello" }],
      max_tokens: 1 // Request minimum tokens to minimize cost
    });
    
    // If test succeeded, update the client with the new key
    updateAnthropicClient(testApiKey);
    
    return { 
      valid: true, 
      message: "API key is valid and has been updated" 
    };
  } catch (error: any) {
    console.error("Error testing Anthropic API key:", error);
    
    // Check for rate limit errors
    if (error?.status === 429) {
      return { 
        valid: false, 
        message: "API key is rate limited. Please try again later or use a different key." 
      };
    }
    
    // Check for authentication errors
    if (error?.status === 401 || error?.message?.includes('auth') || error?.message?.includes('key')) {
      return { 
        valid: false, 
        message: "API key is invalid or unauthorized" 
      };
    }
    
    return { 
      valid: false, 
      message: `API key validation failed: ${error?.message || 'Unknown error'}` 
    };
  }
}

// Create a function to get the Anthropic client with the latest API key
function getAnthropicClient() {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  const isApiKeyValid = validateApiKey(apiKey);

  if (!isApiKeyValid) {
    console.warn("WARNING: Invalid or missing Anthropic API key. Claude AI features will be unavailable.");
  }

  // Initialize the Anthropic client with the current API key
  return new Anthropic({
    apiKey: apiKey,
  });
}

// Get the initial Anthropic client
let anthropic = getAnthropicClient();

export async function analyzeExpense(text: string): Promise<{ 
  category: string; 
  amount: number; 
  date: string;
  note?: string;
  vendor?: string;
}> {
  try {
    // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
    
    // Get today's date and yesterday's date in YYYY-MM-DD format
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      system: `You are an advanced expense categorization assistant for a personal finance app. Extract detailed expense information from user text.
        
        Return a JSON object with these properties:
        - category: one of [food, transportation, shopping, utilities, entertainment, health, other]
        - amount: the numeric amount of the expense (just the number, no currency symbol)
        - date: in YYYY-MM-DD format (use today's date if not specified)
        - note: additional details about the expense (optional)
        - vendor: the merchant or business name where the expense occurred (optional)
        
        Examples of user inputs and desired outputs (current date: ${today}):
        1. "I spent $25 on lunch yesterday" → {"category": "food", "amount": 25, "date": "${yesterday}", "note": "lunch", "vendor": null}
        2. "Uber ride to airport $45" → {"category": "transportation", "amount": 45, "date": "${today}", "note": "ride to airport", "vendor": "Uber"}
        3. "paid electric bill $120" → {"category": "utilities", "amount": 120, "date": "${today}", "note": "electric bill", "vendor": null}
        
        Be accurate and precise. Only respond with valid JSON.`,
      max_tokens: 1024,
      messages: [
        {
          role: 'user',
          content: text
        }
      ],
      temperature: 0.1 // Lower temperature for more deterministic responses
    });

    // Parse the response
    const contentBlock = response.content[0];
    const content = typeof contentBlock === 'object' && 'text' in contentBlock 
      ? contentBlock.text as string
      : '';
    
    // Handle potential code block formatting in Claude's response
    let jsonContent = content;
    // Check if response is wrapped in a code block
    if (content.includes('```json') || content.includes('```')) {
      // Extract JSON from code block
      const matches = content.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (matches && matches[1]) {
        jsonContent = matches[1].trim();
      }
    }
    
    // Parse the JSON
    try {
      const result = JSON.parse(jsonContent);
      
      // Ensure the category is valid
      if (result.category && !expenseCategories.includes(result.category)) {
        result.category = 'other';
      }
      
      // Ensure amount is a number
      if (result.amount) {
        result.amount = Number(result.amount);
      }
      
      // Ensure date is in the correct format (YYYY-MM-DD) and not from 2023
      if (result.date) {
        // Check if it's from 2023 (likely a hardcoded date from the examples)
        if (result.date.startsWith('2023-')) {
          console.log("Overriding old date from 2023:", result.date);
          result.date = new Date().toISOString().split('T')[0];
        }
        // Check if it matches the format YYYY-MM-DD
        if (!/^\d{4}-\d{2}-\d{2}$/.test(result.date)) {
          try {
            // Try to parse and format it
            const date = new Date(result.date);
            if (!isNaN(date.getTime())) {
              result.date = date.toISOString().split('T')[0];
            } else {
              // If we can't parse it, use today's date
              result.date = new Date().toISOString().split('T')[0];
            }
          } catch (e) {
            // If parsing fails, default to today
            result.date = new Date().toISOString().split('T')[0];
          }
        }
      } else {
        // If no date provided, use today
        result.date = new Date().toISOString().split('T')[0];
      }
      
      return result;
    } catch (parseError) {
      console.error('Error parsing JSON from Anthropic response:', parseError);
      console.log('Raw response content:', content);
      
      // Return fallback response
      throw {
        message: 'Failed to analyze expense text. Please try again with clearer description.',
        error: 'PARSING_ERROR',
        details: 'Could not parse AI response'
      };
    }
  } catch (error: any) {
    console.error('Error analyzing expense with Anthropic:', error);
    
    // More detailed error handling with structured errors
    if (error?.status === 401 || error?.message?.includes('API key')) {
      const errorObj = {
        message: 'Invalid or missing Anthropic API key. Please update your API key in the Replit Secrets section.',
        error: 'API_KEY_ERROR',
        details: error?.message || 'Authentication failed'
      };
      throw errorObj;
    }
    
    // Check for rate limiting
    if ((error.status === 429) || 
        (error.message && typeof error.message === 'string' && error.message.includes('quota')) ||
        (error.error?.type === 'rate_limit_error')) {
      const errorResponse = {
        message: 'Anthropic API rate limit exceeded. Please update your API key in Replit Secrets or try again later.',
        error: 'RATE_LIMIT_ERROR',
        details: error.message || 'Rate limit or quota exceeded'
      };
      throw errorResponse;
    }
    
    // Check for network issues
    const errorObj = error as any;
    
    if (errorObj.code === 'ENOTFOUND' || errorObj.code === 'ECONNREFUSED' || errorObj.code === 'ETIMEDOUT') {
      const errorResponse = {
        message: 'Network error connecting to Anthropic. Please check your internet connection.',
        error: 'NETWORK_ERROR',
        details: typeof errorObj.message === 'string' ? errorObj.message : 'Network error'
      };
      throw errorResponse;
    }
    
    // General error
    const errorResponse = {
      message: 'Failed to analyze expense: ' + (typeof errorObj.message === 'string' ? errorObj.message : 'Unknown error'),
      error: 'ANTHROPIC_API_ERROR',
      details: JSON.stringify(error)
    };
    throw errorResponse;
  }
}

export async function generateFinancialInsights(expenses: Expense[]): Promise<{
  summary: string;
  tips: string[];
  trends: string;
  error?: string;
}> {
  if (!expenses.length) {
    return {
      summary: "You don't have any expenses recorded yet.",
      tips: ["Start tracking your expenses to get personalized insights."],
      trends: "No spending trends to analyze yet."
    };
  }

  try {
    // Prepare the expense data for the API call
    const expenseData = expenses.map(exp => ({
      amount: exp.amount,
      category: exp.category,
      date: exp.date,
      note: exp.note
    }));

    const totalSpent = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    
    // Call Anthropic API to generate insights
    // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      system: `You are an advanced financial advisor with expertise in personal finance. Analyze the user's expenses in detail to provide personalized insights.
        
        Return a JSON object with the following properties:
        - summary: A clear, concise summary of their spending patterns (1-2 sentences)
        - tips: An array of 3 highly personalized, actionable tips to help them manage their finances better, based on their specific spending patterns
        - trends: A data-driven analysis of spending trends, highlighting patterns and potential areas for improvement
        
        When analyzing expenses:
        - Consider the distribution across categories
        - Look for unusual or excessive spending
        - Identify opportunities for saving
        - Consider timing and frequency of expenses
        - Note any positive financial behaviors to reinforce
        
        Keep the analysis practical, positive, and actionable. Only respond with valid JSON.`,
      max_tokens: 1500,
      messages: [
        {
          role: 'user',
          content: `Here are my expenses: ${JSON.stringify(expenseData)}. 
                    Total spent: $${totalSpent.toFixed(2)}.`
        }
      ],
      temperature: 0.5
    });

    // Parse the response
    const contentBlock = response.content[0];
    const content = typeof contentBlock === 'object' && 'text' in contentBlock 
      ? contentBlock.text as string
      : '';
    
    // Handle potential code block formatting in Claude's response
    let jsonContent = content;
    // Check if response is wrapped in a code block
    if (content.includes('```json') || content.includes('```')) {
      // Extract JSON from code block
      const matches = content.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (matches && matches[1]) {
        jsonContent = matches[1].trim();
      }
    }
    
    // Parse the JSON
    try {
      const result = JSON.parse(jsonContent);
      return result;
    } catch (parseError) {
      console.error('Error parsing JSON from Anthropic response:', parseError);
      console.log('Raw response content:', content);
      
      // Return fallback response
      return {
        summary: "We analyzed your recent expenses.",
        tips: [
          "Track your expenses consistently to identify spending patterns.", 
          "Create a budget that allocates funds to necessities first.",
          "Consider the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings."
        ],
        trends: "Add more expenses to get personalized trend analysis.",
        error: "Error processing AI-generated insights."
      };
    }
  } catch (error) {
    console.error('Error generating insights with Anthropic:', error);
    
    // Check for quota/rate limit errors
    let errorMessage = "We couldn't generate personalized insights at this time.";
    
    if (error instanceof Error) {
      const errorObj = error as any; // Cast to any to allow property access
      
      if ((errorObj.status === 429) || 
          (errorObj.message && typeof errorObj.message === 'string' && errorObj.message.includes('quota')) ||
          (errorObj.error?.type === 'rate_limit_error')) {
        errorMessage = "Anthropic API rate limit exceeded. Please update your API key to get AI-powered financial insights.";
      } else if (errorObj.status === 401 || errorObj.status === 403) {
        errorMessage = "Unable to connect to Anthropic. Please check your API key.";
      }
    }
    
    return {
      summary: "Here are some general financial tips based on best practices.",
      tips: [
        "Track your expenses consistently to identify spending patterns.", 
        "Create a budget that allocates funds to necessities first.",
        "Consider the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings."
      ],
      trends: "Add more expenses to get personalized trend analysis.",
      error: errorMessage
    };
  }
}

export async function enhanceNaturalLanguageQuery(query: string): Promise<string> {
  try {
    // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      system: `You are an advanced expense tracking assistant that processes natural language queries about finances and expenses.
        
        You have the following capabilities:
        1. Add expenses - Parse amount, category, date, and description
        2. Analyze spending - Show summary by category or time period
        3. Handle complex time-based queries like "last quarter" or "March 2024"
        4. Recognize expense categories: food, transportation, shopping, utilities, entertainment, health, other
        
        When a user inputs a query:
        - If it's an expense (e.g., "spent $20 on lunch"), reformat it as "I spent $20 on food for lunch"
        - If it's about spending analysis (e.g., "how much did I spend on groceries"), reformat it as "view summary for food category"
        - If it's about time periods (e.g., "expenses from last month"), reformat it as "monthly report for last month"
        - If it's a budget question, reformat it clearly to maintain original intent
        
        Only output the enhanced query text, nothing else. Keep it concise and natural.`,
      max_tokens: 150,
      messages: [
        {
          role: 'user',
          content: query
        }
      ],
      temperature: 0.2
    });

    const contentBlock = response.content[0];
    const content = typeof contentBlock === 'object' && 'text' in contentBlock 
      ? contentBlock.text as string
      : '';
    if (!content) {
      return query;
    }
    return content;
  } catch (error) {
    console.error('Error enhancing query with Anthropic:', error);
    return query; // Return the original query if there's an error
  }
}

export async function analyzeReceipt(base64Image: string): Promise<{
  amount?: number;
  category?: string;
  date?: string;
  vendor?: string;
  note?: string;
  items?: Array<{ name: string; price: number }>;
  confidence: number;
}> {
  try {
    // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
    const response = await anthropic.messages.create({
      model: "claude-3-7-sonnet-20250219",
      system: `You are a receipt scanning expert. Your job is to extract key information from receipt images.
      Extract the following information and return it as a JSON object:
      - amount: the total amount of the receipt (as a number, no currency symbol)
      - category: categorize this receipt into one of these categories: ${expenseCategories.join(', ')}
      - date: the date on the receipt in YYYY-MM-DD format (use today's date if not found)
      - vendor: the merchant or business name
      - note: a brief description summarizing what was purchased (optional)
      - items: an array of items purchased with name and price (if visible in receipt)
      - confidence: your confidence in the extraction on a scale of 0 to 1

      Only include fields where you have high confidence.
      Return valid JSON.`,
      max_tokens: 1500,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this receipt image and extract expense information:"
            },
            {
              type: "image",
              source: {
                type: "base64",
                media_type: "image/jpeg",
                data: base64Image
              }
            }
          ]
        }
      ]
    });

    const contentBlock = response.content[0];
    const content = typeof contentBlock === 'object' && 'text' in contentBlock 
      ? contentBlock.text as string
      : '';
    
    // Handle potential code block formatting in Claude's response
    let jsonContent = content;
    // Check if response is wrapped in a code block
    if (content.includes('```json') || content.includes('```')) {
      // Extract JSON from code block
      const matches = content.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (matches && matches[1]) {
        jsonContent = matches[1].trim();
      }
    }
    
    // Parse the JSON
    try {
      const result = JSON.parse(jsonContent);
      
      // Validate the category to ensure it's in our list
      if (result.category && !expenseCategories.includes(result.category)) {
        result.category = 'other';
      }
      
      // Ensure amount is a number
      if (result.amount) {
        result.amount = Number(result.amount);
      }
      
      // Ensure confidence is a number between 0 and 1
      if (result.confidence) {
        result.confidence = Math.max(0, Math.min(1, Number(result.confidence)));
      } else {
        result.confidence = 0.7; // Default medium-high confidence
      }
      
      // Ensure date is in the correct format (YYYY-MM-DD) and not from 2023
      if (result.date) {
        // Check if it's from 2023 (likely a hardcoded date from the examples)
        if (result.date.startsWith('2023-')) {
          console.log("Overriding old date from 2023:", result.date);
          result.date = new Date().toISOString().split('T')[0];
        }
        // Check if it matches the format YYYY-MM-DD
        else if (!/^\d{4}-\d{2}-\d{2}$/.test(result.date)) {
          try {
            // Try to parse and format it
            const date = new Date(result.date);
            if (!isNaN(date.getTime())) {
              result.date = date.toISOString().split('T')[0];
            } else {
              // If we can't parse it, use today's date
              result.date = new Date().toISOString().split('T')[0];
            }
          } catch (e) {
            // If parsing fails, default to today
            result.date = new Date().toISOString().split('T')[0];
          }
        }
      } else {
        // If no date provided, use today
        result.date = new Date().toISOString().split('T')[0];
      }
      
      return result;
    } catch (parseError) {
      console.error('Error parsing JSON from Anthropic receipt analysis:', parseError);
      console.log('Raw response content:', content);
      
      // Return fallback response
      throw {
        message: 'Failed to analyze receipt image data. The image might not be clear enough or does not contain recognizable receipt information.',
        error: 'PARSING_ERROR',
        details: 'Could not parse AI response'
      };
    }
  } catch (error) {
    console.error('Error analyzing receipt with Anthropic:', error);
    throw {
      message: 'Failed to analyze receipt image',
      error: 'ANTHROPIC_API_ERROR',
      details: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}